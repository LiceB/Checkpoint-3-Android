package com.example.alicebianchi_rm86850_estergalesso_rm89350.view

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.alicebianchi_rm86850_estergalesso_rm89350.R
import com.example.alicebianchi_rm86850_estergalesso_rm89350.databinding.ActivityMainBinding
import com.example.alicebianchi_rm86850_estergalesso_rm89350.model.Constantes
import com.example.alicebianchi_rm86850_estergalesso_rm89350.model.ItensModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class MainActivity : AppCompatActivity() {

    lateinit var bind : ActivityMainBinding
    val adapter = ItensAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        val itens = getItens()

        bind.listaItens.adapter = adapter
        bind.listaItens.layoutManager = LinearLayoutManager(this)
        adapter.setList(itens)

        bind.botaoAdicionar.setOnClickListener{
            val quantidade = Integer.parseInt(bind.editQtd.text.toString())
            val item = bind.editItem.text.toString()
            itens.add(ItensModel(false, quantidade, item))
            saveList(itens)
            adapter.setList(itens)
        }

    }

    private fun getItens(): MutableList<ItensModel> {
        val shared = getSharedPreferences(Constantes.ITENS_BASE, Context.MODE_PRIVATE)
        val jsonLista = shared.getString(Constantes.LISTA_ITENS, null)
        if (jsonLista == null){
            return mutableListOf()
        }else{
            val type: Type = object : TypeToken<MutableList<ItensModel>>() {}.type
            val listaItens = Gson().fromJson<MutableList<ItensModel>>(jsonLista, type)
            return listaItens
        }
    }

    fun saveList(listaItens:List<ItensModel>){
        val listJson = Gson().toJson(listaItens)

        val sharedPreferences = getSharedPreferences(Constantes.ITENS_BASE, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(Constantes.LISTA_ITENS, listJson)
        editor.apply()
    }


}