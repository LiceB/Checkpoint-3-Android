package com.example.alicebianchi_rm86850_estergalesso_rm89350.model

object Constantes {
    const val LISTA_ITENS = "LISTA_ITENS"
    const val ITENS_BASE = "ITENS_BASE"
}