package com.example.alicebianchi_rm86850_estergalesso_rm89350.model

data class ItensModel(
    //false : pendente, true : pronto
    val status : Boolean,
    val quantidade : Int,
    val nomeItem : String
)
