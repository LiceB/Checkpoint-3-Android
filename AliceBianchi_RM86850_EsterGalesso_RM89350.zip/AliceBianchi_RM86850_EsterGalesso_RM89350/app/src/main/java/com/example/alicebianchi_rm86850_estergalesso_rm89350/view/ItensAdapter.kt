package com.example.alicebianchi_rm86850_estergalesso_rm89350.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.alicebianchi_rm86850_estergalesso_rm89350.databinding.ItemModelBinding
import com.example.alicebianchi_rm86850_estergalesso_rm89350.model.ItensModel

class ItensAdapter : RecyclerView.Adapter<ItensAdapter.ItensHolder>() {

    private val itens: MutableList<ItensModel> = mutableListOf()

    class ItensHolder(val itemHolder: ItemModelBinding) : RecyclerView.ViewHolder(itemHolder.root) {
        fun bind(item: ItensModel) {
            if(item.status) {
                itemHolder.txtStatus.text = "Pronto"
            } else { itemHolder.txtStatus.text = "Pendente" }
            itemHolder.txtDescricaoItem.text = item.nomeItem
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItensHolder {
        return ItensHolder(
            ItemModelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItensHolder, position: Int) {
        holder.bind(itens[position])
        holder.itemHolder.imagemDeletar.setOnClickListener {
            removeItemLista(itens[position])
        }
    }

    private fun removeItemLista(removido: ItensModel) {
        val removedIndex = itens.indexOf(removido)
        itens.remove(removido)
        notifyItemRemoved(removedIndex)
        notifyItemChanged(removedIndex, itens.size)
    }

    override fun getItemCount(): Int = itens.count()

    fun setList(newItens: List<ItensModel>){
        itens.clear()
        itens.addAll(newItens)
        notifyDataSetChanged()
    }

    fun addItem(item: ItensModel) {
        itens.add(item)
        notifyItemInserted(itens.count())
    }

}